# Zod schemas per entity
